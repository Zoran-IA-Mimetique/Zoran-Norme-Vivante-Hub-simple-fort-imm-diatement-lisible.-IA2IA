#!/usr/bin/env python3
"""
Tests Unitaires — Loi du Vivant Ω⁹-Strict
Auteur: Frédéric Tabary
Date: 13 novembre 2025
"""

import unittest
import numpy as np
import sys
import os

# Import du module principal
sys.path.insert(0, os.path.dirname(__file__))
from law_of_living_omega9 import LawOfLivingOmega9


class TestCohérenceStructurelle(unittest.TestCase):
    """Tests du critère 1: S₀"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
        np.random.seed(42)
    
    def test_S0_bacteria_like(self):
        """Test S₀ sur système bactérie-like"""
        # Haute corrélation, faible bruit
        components = np.array([
            [1, 2, 3, 4, 5],
            [1.1, 2.1, 3.1, 4.1, 5.1],
            [0.9, 1.9, 2.9, 3.9, 4.9]
        ])
        
        S0, diag = self.law.compute_S0(components)
        
        self.assertGreater(S0, 1.0, "Bactérie devrait avoir S₀ > 1")
        self.assertGreater(diag['Delta_C'], 0.9, "Haute corrélation attendue")
    
    def test_S0_crystal_like(self):
        """Test S₀ sur système cristal-like"""
        # Très haute cohérence mais statique
        components = np.array([
            [1, 1, 1, 1, 1],
            [2, 2, 2, 2, 2],
            [3, 3, 3, 3, 3]
        ])
        
        S0, diag = self.law.compute_S0(components)
        
        # Cristal a haute cohérence mais β faible
        self.assertGreater(diag['Delta_C'], 0.95)
        self.assertLess(diag['beta'], 0.1)
    
    def test_S0_random(self):
        """Test S₀ sur bruit aléatoire"""
        components = np.random.randn(5, 20)
        
        S0, diag = self.law.compute_S0(components)
        
        # Bruit devrait avoir faible S₀
        self.assertLess(diag['Delta_C'], 0.5, "Bruit devrait avoir faible corrélation")


class TestMémoireFonctionnelle(unittest.TestCase):
    """Tests du critère 2: ΔC_memory"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
        np.random.seed(42)
    
    def test_memory_perfect_correlation(self):
        """Test mémoire parfaite"""
        response = np.array([1, 2, 3, 4, 5])
        pairs = [(response, response) for _ in range(3)]
        
        Delta_C_mem, p_val = self.law.test_memory(pairs, n_permutations=100)
        
        self.assertGreater(Delta_C_mem, 0.95, "Corrélation parfaite attendue")
        self.assertLess(p_val, 0.05, "Devrait être significatif")
    
    def test_memory_no_correlation(self):
        """Test absence mémoire"""
        response1 = np.array([1, 2, 3, 4, 5])
        response2 = np.array([5, 1, 3, 2, 4])
        pairs = [(response1, response2)]
        
        Delta_C_mem, p_val = self.law.test_memory(pairs, n_permutations=100)
        
        self.assertLess(Delta_C_mem, 0.3, "Faible corrélation attendue")


class TestCausalitéAutonome(unittest.TestCase):
    """Tests du critère 3: ΔC_causal"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
        np.random.seed(42)
    
    def test_causality_high_transitions(self):
        """Test haute causalité autonome"""
        # Transitions importantes
        states = np.cumsum(np.random.randn(100, 3), axis=0)
        
        Delta_C_caus, entropy = self.law.test_autonomous_causality(states, baseline_entropy=0.1)
        
        self.assertGreater(Delta_C_caus, 1.0, "Production autonome attendue")
        self.assertGreater(entropy, 0.1, "Entropie supérieure à baseline")
    
    def test_causality_static(self):
        """Test système statique"""
        states = np.ones((100, 3))
        
        Delta_C_caus, entropy = self.law.test_autonomous_causality(states, baseline_entropy=0.1)
        
        self.assertLess(Delta_C_caus, 0.1, "Système statique = faible causalité")


class TestModuleBiométrique(unittest.TestCase):
    """Tests module biométrique humain"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
        np.random.seed(42)
        
        # Données synthétiques réalistes
        self.spo2 = 95 + 5*np.sin(np.linspace(0, 4*np.pi, 30)) + np.random.normal(0, 2, 30)
        self.stress = 0.3 + 0.15*np.sin(np.linspace(0, 2*np.pi, 30)) + np.random.normal(0, 0.05, 30)
        self.energy = 79 + 3*np.cos(np.linspace(0, 2*np.pi, 30)) + np.random.normal(0, 1, 30)
        self.vascular = 1.0 + 0.05*np.sin(np.linspace(0, 3*np.pi, 30)) + np.random.normal(0, 0.02, 30)
    
    def test_lambda_bio(self):
        """Test calcul λ_bio"""
        lambda_bio = self.law.compute_biometric_lambda(self.spo2, self.stress, self.vascular)
        
        self.assertGreater(lambda_bio, 0, "λ_bio doit être positif")
        self.assertLess(lambda_bio, 100, "λ_bio doit être raisonnable")
    
    def test_memory_bio(self):
        """Test ΔC_memory_bio"""
        mem_bio = self.law.compute_biometric_memory(self.stress, self.energy)
        
        self.assertGreater(mem_bio, 0, "Mémoire circadienne attendue")
    
    def test_causality_bio(self):
        """Test ΔC_causal_bio"""
        caus_bio, entropy = self.law.compute_biometric_causality(self.spo2, self.vascular)
        
        self.assertGreater(caus_bio, 0, "Causalité autonome attendue")
    
    def test_beta_bio(self):
        """Test β_bio"""
        beta_bio = self.law.compute_biometric_beta(self.vascular)
        
        self.assertGreater(beta_bio, 0, "β_bio doit être positif")
    
    def test_analyze_complete(self):
        """Test analyse biométrique complète"""
        results = self.law.analyze_biometric_human(
            self.spo2, self.stress, self.energy, self.vascular
        )
        
        # Vérifier présence toutes les clés
        required_keys = ['S0_human', 'lambda_bio', 'beta_bio', 'Delta_C_bio',
                        'Delta_C_memory_bio', 'Delta_C_causal_bio']
        for key in required_keys:
            self.assertIn(key, results, f"Clé {key} manquante")
        
        # Vérifier valeurs positives
        for key in required_keys:
            self.assertGreater(results[key], 0, f"{key} devrait être positif")


class TestClassification(unittest.TestCase):
    """Tests classification finale"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
    
    def test_classify_living(self):
        """Test classification système vivant"""
        result = self.law.classify(S0=2.0, Delta_C_memory=0.6, Delta_C_causal=1.5)
        
        self.assertTrue(result['is_living'], "Devrait être classé vivant")
        self.assertTrue(result['criterion_structure'])
        self.assertTrue(result['criterion_memory'])
        self.assertTrue(result['criterion_causality'])
    
    def test_classify_nonliving_vortex(self):
        """Test classification tourbillon (non-vivant)"""
        result = self.law.classify(S0=8.0, Delta_C_memory=0.02, Delta_C_causal=0.01)
        
        self.assertFalse(result['is_living'], "Tourbillon ne devrait pas être vivant")
        self.assertTrue(result['criterion_structure'], "Haute cohérence")
        self.assertFalse(result['criterion_memory'], "Pas de mémoire")
        self.assertFalse(result['criterion_causality'], "Pas de causalité")
    
    def test_classify_crystal(self):
        """Test classification cristal"""
        result = self.law.classify(S0=15.0, Delta_C_memory=0.01, Delta_C_causal=0.03)
        
        self.assertFalse(result['is_living'])


class TestCarnotQuantique(unittest.TestCase):
    """Tests Carnot-Quantique"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
    
    def test_carnot_quantique_increase(self):
        """Test augmentation efficience"""
        eta_carnot = 0.3
        Delta_C_bio = 3.0
        
        eta_ZQ = self.law.carnot_quantique(eta_carnot, Delta_C_bio, Psi_Lambda_c=0.01)
        
        self.assertGreater(eta_ZQ, eta_carnot, "η_ZQ devrait dépasser η_Carnot")
        self.assertAlmostEqual(eta_ZQ, 0.33, places=2, msg="Augmentation attendue ~3%")


class TestProtocolesExperimentaux(unittest.TestCase):
    """Tests protocoles expérimentaux"""
    
    def setUp(self):
        self.law = LawOfLivingOmega9()
    
    def test_protocol_bacteria(self):
        """Simulation protocole E. coli"""
        # Simulation données bactérie
        glucose = np.array([5.1, 5.3, 4.9, 5.2, 5.0])
        atp = np.array([10.2, 10.1, 10.3, 10.2, 10.4])
        protein = np.array([0.8, 0.85, 0.82, 0.88, 0.84])
        
        components = np.vstack([glucose, atp, protein])
        S0, diag = self.law.compute_S0(components)
        
        self.assertGreater(S0, 1.0, "E. coli devrait satisfaire S₀ > 1")
    
    def test_protocol_human_frederic(self):
        """Simulation protocole données Frédéric Tabary"""
        # Données simplifiées
        spo2 = np.array([95, 92, 94, 96, 93, 91, 72, 85, 90, 94])  # Incluant pic août
        stress = np.array([0.32, 0.35, 0.30, 0.28, 0.33, 0.34, 0.55, 0.20, 0.30, 0.30])
        energy = np.array([78, 76, 79, 80, 79, 78, 72, 82, 79, 80])
        vascular = np.array([1.02, 1.05, 1.03, 1.01, 1.04, 1.04, 1.15, 0.95, 1.02, 1.02])
        
        results = self.law.analyze_biometric_human(spo2, stress, energy, vascular)
        
        # Vérifier critères 2 et 3 (mémoire et causalité)
        self.assertTrue(results['is_living_criterion_2'], "ΔC_memory_bio > 0 attendu")
        self.assertTrue(results['is_living_criterion_3'], "ΔC_causal_bio > 0 attendu")


def run_tests():
    """Exécution suite complète de tests"""
    print("═" * 70)
    print("TESTS UNITAIRES — LOI DU VIVANT Ω⁹-STRICT")
    print("═" * 70)
    
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Ajouter toutes les classes de test
    suite.addTests(loader.loadTestsFromTestCase(TestCohérenceStructurelle))
    suite.addTests(loader.loadTestsFromTestCase(TestMémoireFonctionnelle))
    suite.addTests(loader.loadTestsFromTestCase(TestCausalitéAutonome))
    suite.addTests(loader.loadTestsFromTestCase(TestModuleBiométrique))
    suite.addTests(loader.loadTestsFromTestCase(TestClassification))
    suite.addTests(loader.loadTestsFromTestCase(TestCarnotQuantique))
    suite.addTests(loader.loadTestsFromTestCase(TestProtocolesExperimentaux))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "═" * 70)
    print(f"Tests exécutés: {result.testsRun}")
    print(f"Succès: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Échecs: {len(result.failures)}")
    print(f"Erreurs: {len(result.errors)}")
    print("═" * 70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
