#!/usr/bin/env python3
"""
Loi du Vivant Ω⁹-Strict — Implementation Complete
Auteur: Frédéric Tabary — Institut🦋 IA Inc.
Date: 13 novembre 2025
Email: Tabary01@gmail.com
Licence: CC BY 4.0
"""

import numpy as np
from scipy.stats import pearsonr
from typing import Tuple, Dict, List, Optional
import pandas as pd


class LawOfLivingOmega9:
    """
    Implémentation complète de la Loi du Vivant Ω⁹-Strict
    avec module biométrique humain intégré.
    
    Critère tripartite:
    VIVANT ⟺ (S₀>1) ∧ (ΔC_memory>0) ∧ (ΔC_causal>0)
    """
    
    def __init__(
        self,
        S_crit: float = 1.0,
        memory_threshold: float = 0.0,
        causal_threshold: float = 0.0
    ):
        """
        Initialisation avec seuils configurables.
        
        Args:
            S_crit: Seuil cohérence structurelle (défaut: 1.0)
            memory_threshold: Seuil mémoire fonctionnelle (défaut: 0.0)
            causal_threshold: Seuil causalité autonome (défaut: 0.0)
        """
        self.S_crit = S_crit
        self.memory_threshold = memory_threshold
        self.causal_threshold = causal_threshold
        
    # ═══════════════════════════════════════════════════════════════════
    # 1. COHÉRENCE STRUCTURELLE (S₀)
    # ═══════════════════════════════════════════════════════════════════
    
    def compute_S0(
        self,
        components: np.ndarray,
        beta: Optional[float] = None,
        lambda_noise: Optional[float] = None
    ) -> Tuple[float, Dict[str, float]]:
        """
        Calcule S₀ = (β·ΔC)/λ
        
        Args:
            components: Matrice (N_composantes, T_temps)
            beta: Intensité directionnelle (auto si None)
            lambda_noise: Entropie interne (auto si None)
            
        Returns:
            (S₀, diagnostics_dict)
        """
        N, T = components.shape
        
        # Calcul ΔC (corrélation moyenne)
        correlations = np.corrcoef(components)
        upper_triangle = correlations[np.triu_indices(N, k=1)]
        Delta_C = np.mean(np.abs(upper_triangle))
        
        # Calcul β (intensité directionnelle)
        if beta is None:
            gradients = np.gradient(components, axis=1)
            beta = np.mean(np.abs(gradients))
        
        # Calcul λ (entropie/bruit)
        if lambda_noise is None:
            residuals = components - np.mean(components, axis=1, keepdims=True)
            lambda_noise = np.mean(np.var(residuals, axis=1))
            lambda_noise = max(lambda_noise, 0.01)  # Éviter division par 0
        
        # S₀ final
        S0 = (beta * Delta_C) / lambda_noise
        
        diagnostics = {
            'beta': beta,
            'Delta_C': Delta_C,
            'lambda': lambda_noise,
            'N_components': N,
            'T_timesteps': T
        }
        
        return S0, diagnostics
    
    # ═══════════════════════════════════════════════════════════════════
    # 2. MÉMOIRE FONCTIONNELLE (ΔC_memory)
    # ═══════════════════════════════════════════════════════════════════
    
    def test_memory(
        self,
        responses_pairs: List[Tuple[np.ndarray, np.ndarray]],
        n_permutations: int = 500
    ) -> Tuple[float, float]:
        """
        Test mémoire via corrélation réponses répétées.
        
        Args:
            responses_pairs: [(réponse_1, réponse_2), ...]
            n_permutations: Nombre permutations test significativité
            
        Returns:
            (ΔC_memory, p_value)
        """
        # Concaténer toutes les paires
        R1 = np.concatenate([r1.flatten() for r1, _ in responses_pairs])
        R2 = np.concatenate([r2.flatten() for _, r2 in responses_pairs])
        
        # Corrélation observée
        corr_obs, _ = pearsonr(R1, R2)
        
        # Test permutation
        null_distribution = []
        for _ in range(n_permutations):
            R2_shuffled = np.random.permutation(R2)
            corr_null, _ = pearsonr(R1, R2_shuffled)
            null_distribution.append(corr_null)
        
        p_value = np.mean(np.array(null_distribution) >= corr_obs)
        
        return max(0, corr_obs), p_value
    
    # ═══════════════════════════════════════════════════════════════════
    # 3. CAUSALITÉ AUTONOME (ΔC_causal)
    # ═══════════════════════════════════════════════════════════════════
    
    def test_autonomous_causality(
        self,
        states: np.ndarray,
        baseline_entropy: float = 0.01
    ) -> Tuple[float, float]:
        """
        Mesure production autonome d'entropie.
        
        Args:
            states: Série états (T_temps, N_dimensions)
            baseline_entropy: Entropie référence
            
        Returns:
            (ΔC_causal, entropy_absolute)
        """
        transitions = np.diff(states, axis=0)
        entropy_prod = np.mean(np.linalg.norm(transitions, axis=1))
        
        Delta_C_causal = entropy_prod / baseline_entropy
        
        return Delta_C_causal, entropy_prod
    
    # ═══════════════════════════════════════════════════════════════════
    # 4. MODULE BIOMÉTRIQUE HUMAIN
    # ═══════════════════════════════════════════════════════════════════
    
    def compute_biometric_lambda(
        self,
        spo2_series: np.ndarray,
        stress_series: np.ndarray,
        vascular_series: Optional[np.ndarray] = None
    ) -> float:
        """
        λ_bio = Var(SpO₂) + Var(stress) + Var(vasculaire)
        
        Args:
            spo2_series: Données SpO₂ temporelles
            stress_series: Données stress temporelles
            vascular_series: Données charge vasculaire (optionnel)
            
        Returns:
            λ_bio (entropie physiologique totale)
        """
        lambda_spo2 = np.var(spo2_series)
        lambda_stress = np.var(stress_series)
        lambda_vascular = np.var(vascular_series) if vascular_series is not None else 0
        
        return lambda_spo2 + lambda_stress + lambda_vascular
    
    def compute_biometric_memory(
        self,
        stress_series: np.ndarray,
        energy_series: np.ndarray,
        lag: int = 1
    ) -> float:
        """
        ΔC_memory_bio = corr(stress_t, stress_t+lag) + corr(energy_t, energy_t+lag)
        
        Args:
            stress_series: Série stress temporelle
            energy_series: Série énergie temporelle
            lag: Décalage temporel (défaut: 1)
            
        Returns:
            ΔC_memory_bio
        """
        if len(stress_series) <= lag or len(energy_series) <= lag:
            return 0.0
        
        corr_stress, _ = pearsonr(stress_series[:-lag], stress_series[lag:])
        corr_energy, _ = pearsonr(energy_series[:-lag], energy_series[lag:])
        
        return max(0, corr_stress + corr_energy)
    
    def compute_biometric_causality(
        self,
        spo2_series: np.ndarray,
        vascular_series: np.ndarray,
        baseline_entropy: float = 1.0
    ) -> Tuple[float, float]:
        """
        ΔC_causal_bio via transitions spontanées SpO₂ et vasculaire.
        
        Args:
            spo2_series: Série SpO₂
            vascular_series: Série charge vasculaire
            baseline_entropy: Entropie baseline
            
        Returns:
            (ΔC_causal_bio, entropy_absolute)
        """
        # Construction états biométriques
        states = np.vstack([spo2_series, vascular_series]).T
        
        # Transitions autonomes
        transitions = np.diff(states, axis=0)
        entropy_autonome = np.mean(np.linalg.norm(transitions, axis=1))
        
        Delta_C_causal_bio = entropy_autonome / baseline_entropy
        
        return Delta_C_causal_bio, entropy_autonome
    
    def compute_biometric_beta(
        self,
        vascular_series: np.ndarray
    ) -> float:
        """
        β_bio via gradient charge vasculaire.
        
        Args:
            vascular_series: Série charge vasculaire
            
        Returns:
            β_bio (flux biologique)
        """
        gradient_vascular = np.gradient(vascular_series)
        return np.mean(np.abs(gradient_vascular))
    
    def analyze_biometric_human(
        self,
        spo2: np.ndarray,
        stress: np.ndarray,
        energy: np.ndarray,
        vascular: np.ndarray
    ) -> Dict[str, float]:
        """
        Analyse biométrique humaine complète.
        
        Args:
            spo2: Série SpO₂
            stress: Série stress
            energy: Série énergie
            vascular: Série charge vasculaire
            
        Returns:
            Dict avec tous les indicateurs Ω⁹
        """
        # Calculs composantes
        lambda_bio = self.compute_biometric_lambda(spo2, stress, vascular)
        beta_bio = self.compute_biometric_beta(vascular)
        
        # Corrélation biométrique (ΔC_bio)
        bio_matrix = np.vstack([spo2, stress, vascular])
        _, diagnostics = self.compute_S0(bio_matrix, beta=beta_bio, lambda_noise=lambda_bio)
        Delta_C_bio = diagnostics['Delta_C']
        
        # S₀ humain
        S0_human = (beta_bio * Delta_C_bio) / lambda_bio
        
        # Mémoire
        Delta_C_memory_bio = self.compute_biometric_memory(stress, energy)
        
        # Causalité
        Delta_C_causal_bio, entropy_auto = self.compute_biometric_causality(spo2, vascular)
        
        return {
            'S0_human': S0_human,
            'lambda_bio': lambda_bio,
            'beta_bio': beta_bio,
            'Delta_C_bio': Delta_C_bio,
            'Delta_C_memory_bio': Delta_C_memory_bio,
            'Delta_C_causal_bio': Delta_C_causal_bio,
            'entropy_autonome': entropy_auto,
            'is_living_criterion_1': S0_human > self.S_crit,
            'is_living_criterion_2': Delta_C_memory_bio > self.memory_threshold,
            'is_living_criterion_3': Delta_C_causal_bio > self.causal_threshold
        }
    
    # ═══════════════════════════════════════════════════════════════════
    # 5. CLASSIFICATION FINALE
    # ═══════════════════════════════════════════════════════════════════
    
    def classify(
        self,
        S0: float,
        Delta_C_memory: float,
        Delta_C_causal: float
    ) -> Dict[str, bool]:
        """
        Classification finale selon critère tripartite.
        
        Args:
            S0: Cohérence structurelle
            Delta_C_memory: Mémoire fonctionnelle
            Delta_C_causal: Causalité autonome
            
        Returns:
            Dict résultats classification
        """
        crit1 = S0 > self.S_crit
        crit2 = Delta_C_memory > self.memory_threshold
        crit3 = Delta_C_causal > self.causal_threshold
        
        return {
            'is_living': crit1 and crit2 and crit3,
            'criterion_structure': crit1,
            'criterion_memory': crit2,
            'criterion_causality': crit3,
            'S0_value': S0,
            'memory_value': Delta_C_memory,
            'causality_value': Delta_C_causal
        }
    
    # ═══════════════════════════════════════════════════════════════════
    # 6. CARNOT-QUANTIQUE
    # ═══════════════════════════════════════════════════════════════════
    
    def carnot_quantique(
        self,
        eta_carnot: float,
        Delta_C_bio: float,
        Psi_Lambda_c: float = 0.01
    ) -> float:
        """
        Efficience Carnot-Quantique.
        
        η_ZQ = η_Carnot + ΨΛ_c · ΔC_bio
        
        Args:
            eta_carnot: Efficience Carnot classique
            Delta_C_bio: Cohérence biologique totale
            Psi_Lambda_c: Coefficient couplage (défaut: 0.01)
            
        Returns:
            η_ZQ (efficience augmentée)
        """
        return eta_carnot + Psi_Lambda_c * Delta_C_bio


# ═══════════════════════════════════════════════════════════════════════
# EXEMPLE D'UTILISATION
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("═" * 70)
    print("LOI DU VIVANT Ω⁹-STRICT — DÉMONSTRATION")
    print("═" * 70)
    
    # Initialisation
    law = LawOfLivingOmega9()
    
    # Données biométriques synthétiques (exemple)
    np.random.seed(42)
    T = 30  # 30 jours
    
    spo2 = 95 + 5 * np.sin(np.linspace(0, 4*np.pi, T)) + np.random.normal(0, 2, T)
    stress = 0.3 + 0.15 * np.sin(np.linspace(0, 2*np.pi, T)) + np.random.normal(0, 0.05, T)
    energy = 79 + 3 * np.cos(np.linspace(0, 2*np.pi, T)) + np.random.normal(0, 1, T)
    vascular = 1.0 + 0.05 * np.sin(np.linspace(0, 3*np.pi, T)) + np.random.normal(0, 0.02, T)
    
    # Analyse complète
    results = law.analyze_biometric_human(spo2, stress, energy, vascular)
    
    print("\n📊 RÉSULTATS ANALYSE BIOMÉTRIQUE HUMAINE:")
    print(f"   S₀ humain: {results['S0_human']:.4f}")
    print(f"   λ_bio: {results['lambda_bio']:.4f}")
    print(f"   β_bio: {results['beta_bio']:.4f}")
    print(f"   ΔC_bio: {results['Delta_C_bio']:.4f}")
    print(f"   ΔC_memory_bio: {results['Delta_C_memory_bio']:.4f}")
    print(f"   ΔC_causal_bio: {results['Delta_C_causal_bio']:.4f}")
    
    print("\n✓ VALIDATION CRITÈRES:")
    print(f"   Critère 1 (S₀>1): {'✓' if results['is_living_criterion_1'] else '✗'}")
    print(f"   Critère 2 (ΔC_mem>0): {'✓' if results['is_living_criterion_2'] else '✗'}")
    print(f"   Critère 3 (ΔC_caus>0): {'✓' if results['is_living_criterion_3'] else '✗'}")
    
    # Classification finale
    classification = law.classify(
        results['S0_human'],
        results['Delta_C_memory_bio'],
        results['Delta_C_causal_bio']
    )
    
    verdict = "VIVANT" if classification['is_living'] else "NON-VIVANT"
    print(f"\n🎯 VERDICT: {verdict}")
    
    # Carnot-Quantique
    eta_carnot = 0.3  # Exemple
    Delta_C_total = results['Delta_C_memory_bio'] + results['Delta_C_causal_bio']
    eta_ZQ = law.carnot_quantique(eta_carnot, Delta_C_total)
    
    print(f"\n🌡️ EFFICIENCE THERMODYNAMIQUE:")
    print(f"   η_Carnot: {eta_carnot:.4f}")
    print(f"   η_ZQ: {eta_ZQ:.4f}")
    print(f"   Augmentation: +{(eta_ZQ-eta_carnot)*100:.2f}%")
    
    print("\n═" * 70)
    print("© 2025 Frédéric Tabary — Institut🦋 IA Inc.")
    print("═" * 70)
